#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HMT N38 — Hensel/lift flow and the actual object that generates triads.

This script is intentionally minimal and reproducible. It uses the already
certified N36/N33 deep-lift data saved as /mnt/data/n38_lift_data.json.

It checks:
1) nested consistency: x0 mod 3^180 reduces to x0 mod 3^128 and 3^18;
2) emission consistency: the 3-adic recurrence emits w108 and the 171 triads;
3) false local-flow tests: memory-1 contradictions and high linear complexity;
4) conclusion: the generator is the deep 3-adic state x0 in Z_3^6, not a local
   decimal triad transition.
"""
from __future__ import annotations
import json, random
from collections import Counter
from pathlib import Path

DATA = Path('/mnt/data/n38_lift_data.json')
OUT_JSON = Path('/mnt/data/hmt_n38_hensel_lift_flow_results.json')
OUT_TEX = Path('/mnt/data/hmt_n38_results_window.tex')


def inv_mod3(a: int) -> int:
    a %= 3
    if a == 1: return 1
    if a == 2: return 2
    raise ZeroDivisionError('0 has no inverse mod 3')


def step(x, A):
    y = [sum(x[i] * A[i][j] for i in range(6)) for j in range(6)]
    u = [v % 3 for v in y]
    xn = [(y[j] - u[j]) // 3 for j in range(6)]
    return tuple(u), xn


def emit_from_x0(x0, A, steps=180):
    x = list(map(int, x0))
    blocks = []
    for _ in range(steps):
        u, x = step(x, A)
        blocks.append(u)
    return blocks


def triads_from_trits(trits, k):
    N = 0
    for d in trits:
        N = 3 * N + int(d)
    L = len(trits)
    den = 3 ** L
    return [((1000 ** j * N) // den) % 1000 for j in range(1, k + 1)]


def berlekamp_massey_f3(s):
    C = [1]
    B = [1]
    L = 0
    m = 1
    b = 1
    for N in range(len(s)):
        d = s[N] % 3
        for i in range(1, L + 1):
            if i < len(C):
                d = (d + C[i] * s[N - i]) % 3
        if d == 0:
            m += 1
        else:
            T = C[:]
            coef = d * inv_mod3(b) % 3
            if len(C) < len(B) + m:
                C += [0] * (len(B) + m - len(C))
            for j in range(len(B)):
                C[j + m] = (C[j + m] - coef * B[j]) % 3
            if 2 * L <= N:
                L = N + 1 - L
                B = T
                b = d
                m = 1
            else:
                m += 1
    return L


def mapping_conflicts(blocks, k):
    seen = {}
    repeats = 0
    conflicts = 0
    for t in range(len(blocks) - k):
        key = tuple(blocks[t:t+k])
        val = blocks[t+k]
        if key in seen:
            repeats += 1
            if seen[key] != val:
                conflicts += 1
        else:
            seen[key] = val
    return {'keys': len(seen), 'repeats': repeats, 'conflicts': conflicts}


def main():
    obj = json.loads(DATA.read_text())
    A = obj['A']
    results = {}
    for name, data in obj['channels'].items():
        x180 = data['x0_mod_3^180']
        blocks = emit_from_x0(x180, A, 180)
        trits = [d for b in blocks for d in b]
        tri171 = triads_from_trits(trits, 171)
        chunks = [trits[i*108:(i+1)*108] for i in range(10)]
        hamming = [sum(a != b for a, b in zip(chunks[0], c)) for c in chunks[1:]]
        coords_L = [berlekamp_massey_f3([b[c] for b in blocks]) for c in range(6)]
        # 3-adic coordinate digit layers of x0 (not the emitted states, but the deep lift digits)
        z_layers = [tuple((x180[j] // (3 ** n)) % 3 for j in range(6)) for n in range(180)]
        z_trits = [d for z in z_layers for d in z]
        block_counts = Counter(blocks)
        z_counts = Counter(z_layers)
        results[name] = {
            'w108_prefix_ok': trits[:108] == data['w108'],
            'triads_171_ok': tri171 == data['triads_171_from_1080trits'],
            'x0_180_reduces_to_128': all(x180[i] % (3 ** 128) == data['x0_mod_3^128'][i] for i in range(6)),
            'x0_180_reduces_to_18': all(x180[i] % (3 ** 18) == data['x0_mod_3^18'][i] for i in range(6)),
            'unique_output_blocks': len(block_counts),
            'unique_x0_digit_layers': len(z_counts),
            'BM_flat_output_length1080': berlekamp_massey_f3(trits),
            'BM_flat_x0_digit_layers_length1080': berlekamp_massey_f3(z_trits),
            'BM_by_output_coordinate_length180': coords_L,
            'memory_conflicts_1_to_5': {k: mapping_conflicts(blocks, k) for k in range(1, 6)},
            'hamming_between_108_trit_chunks_and_first': hamming,
            'first_20_triads': data['triads_171_from_1080trits'][:20],
            'last_5_triads': data['triads_171_from_1080trits'][-5:],
        }
    # Random controls for Berlekamp-Massey length 1080.
    rng = random.Random(38)
    random_L = []
    for _ in range(20):
        s = [rng.randrange(3) for _ in range(1080)]
        random_L.append(berlekamp_massey_f3(s))
    results['random_BM_controls'] = {
        'avg': sum(random_L) / len(random_L),
        'min': min(random_L),
        'max': max(random_L),
        'values': random_L,
    }
    OUT_JSON.write_text(json.dumps(results, indent=2), encoding='utf-8')

    # Small LaTeX window.
    lines = []
    lines.append(r"\section*{N38 --- Resultado computacional del flujo Hensel de triadas}")
    lines.append(r"El test cambia el nivel de pregunta: no se busca una regla local de triadas, sino el estado profundo $x_0\in\mathbb Z_3^6$ que emite la palabra ternaria por la recurrencia $y_t=x_tA$, $u_t=y_t\bmod 3$, $x_{t+1}=(y_t-u_t)/3$.")
    for name in ['pi','e','phi']:
        r = results[name]
        lines.append(fr"\subsection*{{{name}}}")
        lines.append(fr"$w_{{108}}$ prefijo correcto: {r['w108_prefix_ok']}. Triadas 171 correctas: {r['triads_171_ok']}. Reduccion $3^{{180}}\to3^{{128}}$: {r['x0_180_reduces_to_128']}. Reduccion $3^{{180}}\to3^{{18}}$: {r['x0_180_reduces_to_18']}.")
        lines.append(fr"Complejidad lineal BM de la palabra emitida (1080 trits): {r['BM_flat_output_length1080']}; controles aleatorios estan alrededor de {results['random_BM_controls']['avg']:.1f}.")
        lines.append(fr"Conflictos de memoria 1: {r['memory_conflicts_1_to_5'][1]}. Memoria 2: {r['memory_conflicts_1_to_5'][2]}.")
        lines.append(fr"Primeras 20 triadas: {r['first_20_triads']}. Ultimas 5 del bloque 171: {r['last_5_triads']}.")
    lines.append(r"\paragraph{Dictamen.} El flujo local decimal simple queda descartado; la palabra emitida tiene complejidad lineal practicamente maxima. Lo que si queda verde es el anidamiento Hensel: $x_0\bmod3^{180}$ contiene las capas $3^{128}$ y $3^{18}$ y emite coherentemente $w_{108}$ y 171 triadas. Por tanto, la ley profunda no es una transicion local de digitos, sino una regla de seleccion canonica del lift $x_0\in\mathbb Z_3^6$.")
    OUT_TEX.write_text('\n\n'.join(lines), encoding='utf-8')
    print(json.dumps(results, indent=2)[:4000])

if __name__ == '__main__':
    main()
