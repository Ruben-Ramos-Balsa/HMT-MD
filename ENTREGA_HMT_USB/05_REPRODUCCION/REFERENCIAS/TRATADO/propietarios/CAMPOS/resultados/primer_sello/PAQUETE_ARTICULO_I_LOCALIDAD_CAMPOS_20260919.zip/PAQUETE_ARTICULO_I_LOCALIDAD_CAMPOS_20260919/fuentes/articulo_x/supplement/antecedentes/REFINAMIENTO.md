# Refinamiento, unidad y conservación de memoria en la estructura conjunta HMT

Fecha: 11 de septiembre de 2026. Nota de investigación focal; no modifica las publicaciones consultadas.

## Resultado de la composición

El árbol de emisiones APP–TRIT–TPK ya construido determina una probabilidad proyectiva sobre **todas** sus prolongaciones. De ella se obtiene una inclusión isométrica y unital entre los espacios de observables de dos profundidades consecutivas. En la base de historias enriquecidas, esa inclusión distribuye la amplitud de un prefijo entre todos sus hijos con coeficientes iguales a las raíces de sus probabilidades condicionales. La memoria no se añade para completar la norma: la ruta y el ledger ya pertenecen a las etiquetas generadas, y hacen disjuntos los hijos de padres distintos.

La misma prolongación realiza las cinco construcciones consustanciales del continuo. Su naturalidad permite conservar sus relaciones al refinar; no convierte automáticamente cualquier representación posterior en isométrica. Para transportar una identidad de carga observable/memoria al límite, deben ser naturales tanto la inclusión observable como su proyección ortogonal, el transporte y la carga. Se da abajo el teorema preciso y una realización nonádica explícita.

Procedencia: la arquitectura común, la medida, la naturalidad y el transporte ponderado son `RESULTADO_RECUPERADO`. La reunión de sus consecuencias en espacios de Hilbert y del teorema de carga compatible es una formalización de esos antecedentes, no una reivindicación de prioridad. No se han ejecutado cálculos de constantes ni se emite aquí un certificado científico global.

## 1. Fuentes materiales y localizadores

Las referencias F1–F4 pertenecen a las fuentes del integral seleccionado de 2.249 páginas. N es la narrativa REV02 activa para esta investigación.

- **F1 — Estado, árbol y medida común:** [04b1_estado_arbol_medida_comun.tex](</Users/ruben/Documents/New project/output/REVISION_EDITORIAL_HMT_MD_20260905/01_FUENTES/INTEGRAL/tree/New project/output/ENSAMBLADO_CAUSAL_RESTAURADO_HMT_MD_20260905/fuente/manuscrito/reconstruccion_quirurgica_20260822/parte_ii_estructura_discreta/editor_ready/sources/core/04b1_estado_arbol_medida_comun.tex:15>). APP y multiplicidades, líneas 15–95; TRIT y cociclo de carry, 97–174; odómetro, 176–219; transporte de ambas hojas y memoria afín, 358–446; ledger, 449–487; dominio total y truncamiento, 730–834; supervivencia y multisección completa, 1220–1249; medida y simetrías, 1277–1468.
- **F2 — Operaciones intrínsecas correlativas:** [04b2_operaciones_intrinsecas_correlativas.tex](</Users/ruben/Documents/New project/output/REVISION_EDITORIAL_HMT_MD_20260905/01_FUENTES/INTEGRAL/tree/New project/output/ENSAMBLADO_CAUSAL_RESTAURADO_HMT_MD_20260905/fuente/manuscrito/reconstruccion_quirurgica_20260822/parte_ii_estructura_discreta/editor_ready/sources/core/04b2_operaciones_intrinsecas_correlativas.tex:14>). Registro común de emisión, 14–61; transporte ponderado y Gram, 226–307; acción celular y complejo común, 739–832; cinco operaciones sobre la misma emisión, 872–1025; constructor y naturalidad única, 1028–1118; totalidad y alcance de las realizaciones, 1169–1244.
- **F3 — Terminal, naturalidad y límite:** [04b3_terminal_naturalidad_limite.tex](</Users/ruben/Documents/New project/output/REVISION_EDITORIAL_HMT_MD_20260905/01_FUENTES/INTEGRAL/tree/New project/output/ENSAMBLADO_CAUSAL_RESTAURADO_HMT_MD_20260905/fuente/manuscrito/reconstruccion_quirurgica_20260822/parte_ii_estructura_discreta/editor_ready/sources/core/04b3_terminal_naturalidad_limite.tex:898>). Límite inverso y persistencia simultánea, 898–945; alcance analítico y necesidad de cota, 1172–1181.
- **F4 — Doble lectura:** [base_c17_sin_encabezado.tex](</Users/ruben/Documents/New project/output/REVISION_EDITORIAL_HMT_MD_20260905/01_FUENTES/INTEGRAL/tree/New project/output/ENSAMBLADO_CAUSAL_RESTAURADO_HMT_MD_20260905/fuente/colaboracion/partes_i_ii/source/base_residencias/base_c17_sin_encabezado.tex:668>). Covariancia del marco y compatibilidad excepcional, 668–748; globalización conjunta de las dos evaluaciones, 898–964; contracción de cilindros y equivalencia de evaluación, 966–995.
- **N — Narrativa REV02:** [CONSTANTES_ESTRUCTURA_Y_REALIDAD_FISICA_RECOPILACION_INTEGRA.md](</Users/ruben/Documents/excelencia academica/output/CONSTANTES_ESTRUCTURA_REALIDAD_LIENZO_ACUMULATIVO_20260909/REVISION_EDITORIAL_02_FINAL_20260911/CONSTANTES_ESTRUCTURA_Y_REALIDAD_FISICA_RECOPILACION_INTEGRA.md:5640>). Realización y refinamiento, 5640–5677; fibra completa, unidad y traza, 5711–5728; sección, evaluación, simetría y unidad, 6503–6538; memoria bajo contracción, 7938–7989; cinco construcciones y dos profundidades, 8003–8030; naturalidad conjunta, 8169–8198.

## 2. Recorrido causal efectivo y punto de corte

Se parte de las emisiones de APP, no de un espacio de Hilbert elegido para obtener un balance. Una emisión conserva las dos hojas y sus divisiones

\[
\delta^\diamond=\operatorname{res}^\diamond+9\operatorname{quo}^\diamond,
\qquad \diamond\in\{\Sigma,\Pi\}.
\]

TRIT produce orientación y acarreo mediante

\[
\Delta(\epsilon)=\operatorname{or}(\epsilon)+3\kappa(\epsilon),
\qquad \operatorname{or}(\epsilon)\in\{-1,0,+1\}.
\]

TPK transporta la pareja completa de hojas y actualiza la memoria por

\[
U_{\epsilon_2\epsilon_1}=U_{\epsilon_2}U_{\epsilon_1},\qquad
\mathsf U_\epsilon(m)=\mathsf C_\epsilon m+\kappa(\epsilon),\qquad
\kappa(\epsilon_2\epsilon_1)
=\kappa(\epsilon_2)+\mathsf C_{\epsilon_2}\kappa(\epsilon_1).
\]

El cociclo hace asociativa la composición afín. La frontera de la ruta telescopa, pero su ledger es una **palabra ordenada**, no la suma de sus entradas. El odómetro incrementa la memoria vertical al retornar la fase; el retorno no identifica los estados completos. La transferencia reducida del catálogo no sustituye la acción de las emisiones sobre el árbol; F1, 343–355, separa expresamente ambos tipos.

El estado enriquecido conserva las células intermedias, ambas hojas, residuos, cocientes, orientación, carry, reloj, memoria, frontera, ruta y ledger. Una emisión admisible actualiza conjuntamente esos campos. El truncamiento borra exactamente su última contribución. Una prolongación neutra da una sección del truncamiento, pero registra un paso: no es la ausencia de historia. De ahí proceden la finitud, la no vacuidad y la sobreyectividad de todos los niveles, y después la supervivencia total.

El corte de esta nota es la realización analítica de ese sistema y su memoria. No intervienen valores numéricos objetivo ni constantes convencionales como entradas. Los coeficientes probabilísticos siguientes provienen únicamente del número de emisiones salientes efectivas.

## 3. Refinamiento sobre la multisección completa

Fijemos un prefijo enriquecido real \(x\) de profundidad \(k\). Escribimos

\[
H_n=\operatorname{Term}_{k,k+n}(x),\qquad
\rho_n:H_{n+1}\longrightarrow H_n,
\qquad \Omega_x=\varprojlim_n(H_n,\rho_n).
\]

Cada elemento de \(H_n\) es una prolongación completa hasta ese horizonte, con sus testigos de emisión. Para \(h\in H_n\), los hijos son \(h\epsilon\), para **todas** las emisiones \(\epsilon\in\operatorname{Out}(h)\). Se conservan multiplicidades de operaciones, incluso cuando coinciden datos terminales reducidos. Por F1:

\[
p_h(\epsilon)=\frac1{d(h)}>0,\qquad
d(h)=\#\operatorname{Out}(h),\qquad
\mu_{n+1}(h\epsilon)=\mu_n(h)p_h(\epsilon).
\]

Por tanto,

\[
\sum_{\epsilon\in\operatorname{Out}(h)}\mu_{n+1}(h\epsilon)=\mu_n(h),
\qquad (\rho_n)_*\mu_{n+1}=\mu_n.
\tag{1}
\]

F1, 1355–1379, construye la única probabilidad \(\mu_x\) en \(\Omega_x\) con esas masas de cilindro; todo cilindro no vacío tiene masa positiva. La medida no selecciona una historia ni impone un filtro posterior a la existencia de las cinco construcciones.

### Proposición 1. El refinamiento de observables es isométrico y unital

Sean \(\mathscr L_n=L^2(H_n,\mu_n)\) y

\[
R_n:\mathscr L_n\longrightarrow\mathscr L_{n+1},\qquad
(R_nf)(h\epsilon)=f(h).
\]

Entonces \(R_n^*R_n=I\), \(R_n1=1\), y su adjunto es

\[
(E_ng)(h)=\sum_{\epsilon\in\operatorname{Out}(h)}p_h(\epsilon)g(h\epsilon).
\tag{2}
\]

En particular, \(E_nR_n=I\), \(E_n1=1\), y \(R_nE_n\) es la proyección ortogonal sobre los observables que dependen sólo del prefijo.

**Prueba.** Aplicando (1),

\[
\|R_nf\|_{n+1}^2
=\sum_h\mu_n(h)|f(h)|^2\sum_\epsilon p_h(\epsilon)
=\|f\|_n^2.
\]

El mismo agrupamiento en el producto interno da (2). Las afirmaciones sobre la unidad son puntuales; la afirmación sobre la proyección se sigue de \(E_n=R_n^*\) y \(E_nR_n=I\). Además, \(R_n(fg)=R_nf\,R_ng\) y \(R_n\bar f=\overline{R_nf}\): en los observables finitos es también un homomorfismo unital de álgebras. ∎

Al iterar, \(R_{m,n}=R_{m-1}\cdots R_n\) coincide con el pullback por el truncamiento compuesto. Los pullbacks cilíndricos \(R_{\infty,n}\) realizan el límite inductivo de estos Hilbert en \(L^2(\Omega_x,\mu_x)\). Su unión es densa: los cilindros forman un álgebra que genera la sigma-álgebra, y las funciones simples de ese álgebra son densas en \(L^2\). No se requiere elegir una trayectoria para construir el límite.

### La misma isometría en la base de historias

La identificación unitaria \(W_nf(h)=\sqrt{\mu_n(h)}f(h)\) lleva \(\mathscr L_n\) a \(\ell^2(H_n)\). Conjugando \(R_n\), se obtiene

\[
\widehat R_n\delta_h
=\sum_{\epsilon\in\operatorname{Out}(h)}\sqrt{p_h(\epsilon)}\,\delta_{h\epsilon}.
\tag{3}
\]

Los vectores de la derecha tienen soportes disjuntos para padres distintos, porque \(\rho_n(h\epsilon)=h\). Cada columna tiene norma uno por normalización. Esto demuestra directamente la isometría sobre **las historias enriquecidas ya generadas**, sin imponer que una proyección numérica conserve toda la memoria. El vector unidad se transforma en

\[
\Omega_n=\sum_{h\in H_n}\sqrt{\mu_n(h)}\,\delta_h,
\qquad \widehat R_n\Omega_n=\Omega_{n+1}.
\]

No se añade una copia artificial de \(h\) a un resultado para recuperarlo: \(h\epsilon\) es precisamente la prolongación que el dominio APP–TRIT–TPK ya produjo.

## 4. Las cinco operaciones se prolongan dentro de ese mismo sistema

F2, 14–61, define un único registro \(\mathfrak e_\epsilon\) por emisión. Sus operaciones espectral, solenoidal, de calibre, cohomológica y determinantal dependen de esa misma emisión, con iguales fuente, destino, orientación, carry, frontera, ruta y ledger. La acción celular satisface

\[
\partial\operatorname{Cell}(\epsilon)=\operatorname{Cell}(\epsilon)\partial,
\qquad
\operatorname{Cell}(\epsilon_2\epsilon_1)
=\operatorname{Cell}(\epsilon_2)\operatorname{Cell}(\epsilon_1).
\]

El complejo y su línea determinante son los del mismo objeto; el relleno construido verifica \(\partial h_*=z_--z_+\). La totalidad del constructor no requiere que una trivialización especializada sea acíclica o invertible. Así se conserva la existencia conjunta antes de cualquier lector especializado.

La naturalidad única de F2, 1056–1118, es

\[
u_{(\ell,N'),(k,N)}\mathfrak D_{\ell,N'}(\widehat x_\ell)
=\mathfrak D_{k,N}(\tau_{\ell,k}\widehat x_\ell).
\tag{4}
\]

Su prueba no identifica una arista fina aislada con una arista gruesa ficticia: restringe la **historia de emisiones** y conserva las acciones de sus entradas. El transporte compone sobre las mismas probabilidades de cilindro; los balances utilizan la esperanza condicional y su corrector; incidencia y puertos usan sus mapas celulares; homología y determinante utilizan el mismo mapa de complejos. No son cinco límites de historias escogidas por separado.

Hay dos direcciones que deben distinguirse. Los mapas de estado y de coeficientes van de fino a grueso. Los pullbacks \(R_n\) de la proposición 1 van de los observables gruesos a los finos. La esperanza \(E_n\) vuelve en la dirección de reducción. Esta distinción permite realizar (4) analíticamente sin invertir sus dominios.

F3, 898–945, prolonga los terminales completos y conserva simultáneamente la telescopía polar, Gram y pérdidas, incidencia con medida, cono de retorno y datos Smith–Bockstein. La promoción de una de estas acciones a un operador acotado requiere la norma y la cota correspondiente (F3, 1172–1181). Una familia finita compatible no se convierte sólo por su nombre en un operador acotado del límite.

## 5. Fibras de memoria: criterio de Gram y conservación de la unidad

Para una realización no escalar, asignemos a cada prefijo \(h\) una fibra de Hilbert \(\mathscr M_h\), y a su emisión un transporte lineal tipado
\(I_\epsilon:\mathscr M_h\to\mathscr M_{h\epsilon}\). No se identifica este operador lineal con la actualización afín \(\mathsf U_\epsilon\) sin declarar la representación que la realiza.

Sobre \(\mathscr H_n=\bigoplus_{h\in H_n}\mathscr M_h\), se define

\[
(V_n\xi)_{h\epsilon}=\sqrt{p_h(\epsilon)}I_\epsilon\xi_h.
\]

La disjunción de hijos demuestra la identidad exacta recuperada en F2, 247–262:

\[
\left.V_n^*V_n\right|_{\mathscr M_h}
=\sum_{\epsilon\in\operatorname{Out}(h)}p_h(\epsilon)I_\epsilon^*I_\epsilon.
\tag{5}
\]

El criterio necesario y suficiente para \(V_n\) isométrico es que la suma de (5) sea \(I\) en cada padre. Que **cada** \(I_\epsilon\) sea isométrico es suficiente. También es necesario si previamente todos los \(I_\epsilon\) son contracciones: entonces cada \(I-I_\epsilon^*I_\epsilon\) es positivo, y una suma con pesos estrictamente positivos sólo puede anularse si se anula cada sumando. Sin esta condición adicional, el «exactamente cuando» de F2, 264–266, debe entenderse mediante el criterio de Gram, no como una equivalencia general entre isometría de la suma e isometría de todos los transportes.

En las historias escalares de (3), \(I_\epsilon=1\), por lo que la condición queda demostrada. En fibras analíticas adicionales se conserva (5) y se identifica el supuesto concreto que permite pasar a la isometría.

Si las fibras poseen vectores unitarios distinguidos \(u_h\) y \(I_\epsilon u_h=u_{h\epsilon}\), entonces

\[
V_n\Bigl(\bigoplus_h\sqrt{\mu_n(h)}u_h\Bigr)
=\bigoplus_{h\epsilon}\sqrt{\mu_{n+1}(h\epsilon)}u_{h\epsilon}.
\tag{6}
\]

La isometría por sí sola no afirma (6): conservar la norma y conservar un vector unidad distinguido son propiedades distintas.

## 6. Simetrías y doble lectura sin perder el dominio común

Una simetría reversible coherente del árbol transporta todas las emisiones y sus multiplicidades. F1, 1385–1433, prueba que conserva los grados y las probabilidades de los cilindros. Puede llevar \(\Omega_x\) a \(\Omega_{gx}\); sólo si fija el prefijo actúa dentro de una misma fibra de prolongaciones.

Por ello

\[
(K_gf)(g\omega)=f(\omega)
\]

define una unitaria \(L^2(\Omega_x,\mu_x)\to L^2(\Omega_{gx},\mu_{gx})\). La naturalidad del truncamiento implica \(K_{g,n+1}R_n=R'_nK_{g,n}\), y por adjunción la igualdad correspondiente de esperanzas. En fibras de memoria se exige además el cuadrado

\[
S_{g,h\epsilon}I_\epsilon=I_{g\epsilon}S_{g,h}
\]

con \(S_{g,h}\) unitarios. Es el entrelazador que convierte una simetría del árbol en simetría de esa representación de memoria; no se atribuye por nominalidad a todo grupo excepcional posterior.

Para la doble lectura se toma el calibre inicial y su transporte prefijal declarado en F4. Se trabaja sobre una multisección común \(\Omega_x\) en la que los lectores estén definidos; para el arquimediano esto incluye los intervalos compactos encajados y la contracción de diámetros declarados en F4, 966–982. Es una premisa sobre la realización del lector, no un nuevo criterio de existencia del constructor conjunto. Las identidades finitas son

\[
r_{n,m}Q_n=Q_m\rho_{n,m},\qquad
a_{n,m}R^{\rm arq}_n=R^{\rm arq}_m\rho_{n,m}.
\tag{7}
\]

Determinan la lectura conjunta al límite. Si \(L=(\operatorname{ev}_{\rm arq},Q_\infty)\) y \(\nu=L_*\mu_x\), entonces

\[
C_L:L^2(Y,\nu)\longrightarrow L^2(\Omega_x,\mu_x),
\qquad C_Lf=f\circ L,
\]

es una isometría, pues la igualdad de normas es la definición de medida imagen. Conserva la unidad y sus rangos son los observables medibles respecto de la información publicada por \(L\). Para lectores finitos compatibles, (7) implica también la consistencia de las medidas imagen.

Esta isometría no equivale a que el lector distinga todos los estados. F4, 745–748, especifica que igual corriente visible con distinta memoria oculta puede tener la misma incidencia. El adjunto de \(C_L\) es la esperanza respecto del lector; \(C_LC_L^*\) conserva exactamente esa parte observable. Si una realización ampliada \((L,M)\) es inyectiva, Borel y con inversa medible sobre su imagen —por ejemplo, una inyección continua desde el espacio compacto de historias a un espacio Hausdorff apropiado—, su pullback sí identifica todo el \(L^2\). La memoria requerida es la ya conservada en el estado, no una nueva selección retrospectiva.

## 7. Teorema de paso al límite para la carga observable/memoria

Esta sección tipa el enlace con una identidad de conservación de memoria. El refinamiento canónico de §3 proporciona los mapas isométricos necesarios. Una realización adicional puede usar los de §5 cuando satisface (5).

Sean dos sistemas inductivos de Hilbert \((\mathscr H_n,R_n)\) y \((\mathscr K_n,S_n)\), con inclusiones isométricas. Para cada \(n\), sean

\[
J_n:\mathscr H_n\to\mathscr K_n\text{ isométrico},\quad
P_n=J_nJ_n^*,\quad U_n\text{ unitario en }\mathscr K_n,
\]

y \(\widetilde A_n\) autoadjunto acotado, con \(\sup_n\|\widetilde A_n\|<\infty\). Definimos

\[
A_n=J_n^*\widetilde A_nJ_n,\quad
T_n=J_n^*U_nJ_n,\quad
\eta_n=(I-P_n)U_nJ_n.
\]

Supongamos la conservación y separación a cada nivel,

\[
U_n^*\widetilde A_nU_n=\widetilde A_n,
\qquad [\widetilde A_n,P_n]=0,
\tag{8}
\]

y los siguientes cuadrados de refinamiento:

\[
J_{n+1}R_n=S_nJ_n,\qquad
P_{n+1}S_n=S_nP_n,
\tag{9}
\]
\[
U_{n+1}S_n=S_nU_n,\qquad
\widetilde A_{n+1}S_n=S_n\widetilde A_n.
\tag{10}
\]

**Teorema.** Estas familias inducen operadores acotados en los límites inductivos, con \(J_\infty\) isométrico y \(U_\infty\) unitario, y conservan

\[
A_\infty
=T_\infty^*A_\infty T_\infty
 +\eta_\infty^*\widetilde A_\infty\eta_\infty.
\tag{11}
\]

La misma identidad vale a cada profundidad finita. Si \(\widetilde A_n\geq0\), la carga retenida es positiva. Sin positividad se conserva una forma autoadjunta, no necesariamente una energía positiva.

**Prueba.** Descomponemos \(U_nJ_n=J_nT_n+\eta_n\). Los dos términos pertenecen a \(P_n\mathscr K_n\) y \((I-P_n)\mathscr K_n\). La conmutación de (8) anula los términos cruzados de la forma \(\widetilde A_n\). Aplicando la otra identidad de (8),

\[
A_n=J_n^*U_n^*\widetilde A_nU_nJ_n
=T_n^*A_nT_n+\eta_n^*\widetilde A_n\eta_n.
\]

La segunda igualdad de (9), junto con la primera, implica
\(J_{n+1}^*S_n=R_nJ_n^*\): basta escribir
\(P_{n+1}S_n=S_nJ_nJ_n^*=J_{n+1}R_nJ_n^*\) y multiplicar por \(J_{n+1}^*\).
Por (9)–(10),

\[
T_{n+1}R_n=R_nT_n,\qquad
\eta_{n+1}R_n=S_n\eta_n,\qquad
A_{n+1}R_n=R_nA_n.
\]

Así los operadores se definen sobre las uniones algebraicas de los sistemas. Las isometrías y la cota uniforme permiten extenderlos por continuidad a las completaciones. La compatibilidad de \(U_n^*\) también se deduce de la de \(U_n\), porque ambos niveles son unitarios; el límite es, por ello, unitario y no sólo isométrico. Las proyecciones \(P_n\) inducen una proyección cuyo rango es la clausura de la unión de los rangos de \(J_n\); es \(J_\infty J_\infty^*\). Todas las identidades persisten primero en los vectores de nivel finito y después por densidad. Esto prueba (11). ∎

La compatibilidad de \(J_n\) sola no sustituye la segunda igualdad de (9). Un refinamiento que conserve la inclusión observable pero mezcle su complemento con ella puede alterar el defecto de memoria.

### Realización nonádica explícita compatible

Supongamos \(C_n\) unitario en \(\mathscr H_n\), natural respecto de \(R_n\), y \(A_n\) autoadjunto acotado, uniformemente acotado, natural y con \([A_n,C_n]=0\). Sobre \(\mathscr K_n=\mathscr H_n^{\oplus9}\), definimos

\[
J_nv=\tfrac13(v,\ldots,v),\quad
S_n=R_n^{\oplus9},\quad
U_n(v_1,\ldots,v_9)=(C_nv_9,v_1,\ldots,v_8),
\quad \widetilde A_n=I_9\otimes A_n.
\]

El factor \(1/3\) normaliza las nueve componentes. Las fórmulas verifican directamente (8)–(10), incluida la proyección. La compresión es \(T_n=(8I+C_n)/9\), y

\[
\eta_n^*\widetilde A_n\eta_n
=A_n-T_n^*A_nT_n
=\frac8{81}(I-C_n)^*A_n(I-C_n).
\tag{12}
\]

La última igualdad usa \(C_n^*A_nC_n=A_n\). Por el teorema, (12) vale también al límite. Éste es un enlace efectivo: el refinamiento nonádico o el refinamiento completo de historias puede transportar la carga y su memoria siempre que \(C_n\) y \(A_n\) satisfagan los cuadrados indicados.

Para \(A=I\), la telescopía finita es

\[
\|v\|^2=\|T^Nv\|^2+\sum_{j=0}^{N-1}\|\eta T^jv\|^2.
\]

Por tanto \(v\mapsto(\eta v,\eta Tv,\ldots,\eta T^{N-1}v,T^Nv)\) es una isometría. La fórmula de carga correspondiente sustituye las normas por las formas de \(A\) y \(\widetilde A\). No se elimina el término terminal sin probar su convergencia a cero; la compatibilidad de profundidad no prueba por sí sola esa estabilidad temporal.

Si \(D_{N,n}\) denota esa isometría a profundidad \(n\) y horizonte temporal \(N\), los cuadrados anteriores prueban además

\[
(S_n^{\oplus N}\oplus R_n)D_{N,n}
=D_{N,n+1}R_n.
\]

En efecto, cada componente cumple \(\eta_{n+1}T_{n+1}^jR_n=S_n\eta_nT_n^j\), y la terminal cumple \(T_{n+1}^NR_n=R_nT_n^N\). La acumulación de memoria a horizonte finito y el refinamiento de resolución conmutan. El mismo cálculo prueba equivariancia para una simetría representada por unitarios que entrelacen \(J,U,P,\widetilde A\); no extiende la acción a simetrías para las que esos cuadrados no se hayan construido.

## 8. Unidad algebraica y tracial: fibra completa frente a esquina marcada

La realización nonádica de N, 5667–5728, permite comprobar otra conservación, de tipo diferente. En \(M_{9^d}(\mathbb C)\), con traza normalizada \(\tau_d\),

\[
\iota_d(a)=a\otimes I_9
\]

satisface \(\iota_d(I)=I\), preserva productos y adjuntos, y

\[
\tau_{d+1}(\iota_d(a))=\tau_d(a),\qquad
\|\iota_d(a)\|_{2,\tau_{d+1}}=\|a\|_{2,\tau_d}.
\]

La prueba es \(\operatorname{Tr}(a\otimes I_9)=9\operatorname{Tr}(a)\), compensado por el denominador \(9^{d+1}\). Es la versión matricial del mecanismo de normalización de §3. Su esperanza de retorno es \(\operatorname{id}\otimes\tau_9\).

En cambio, \(a\mapsto a\otimes p_j\) envía la unidad a una proyección propia y divide la traza por nueve. Esta diferencia no se repara llamando «refinamiento» a ambos mapas. La narrativa utiliza precisamente esta distinción para separar conservar la fibra completa de seguir una puerta marcada.

Quedan así tipadas cuatro nociones: la identidad de composición de rutas; la prolongación neutra que añade historia; la función constante \(1\) y la masa total de la probabilidad; y la unidad de un álgebra matricial con su traza. Se relacionan por mapas explícitos, pero no son intercambiables por compartir el nombre «unidad».

## 9. Alcance operativo y falsadores focales

La composición positiva es: emisión con ambas hojas → TRIT con orientación y carry → actualización TPK con ledger → árbol total → probabilidad proyectiva → refinamiento isométrico y unital de observables. Las cinco operaciones se construyen sobre la misma emisión y conservan esa base por la naturalidad única. La doble lectura transporta la medida del mismo dominio; el estado completo sigue reteniendo lo que un lector no separa. Las identidades (9)–(10) permiten combinar esta estructura con la conservación de carga y memoria de (11)–(12).

Los controles que distinguen la composición de un mero cambio de lenguaje son concretos:

- Omitir una emisión o identificar testigos paralelos altera el grado, la medida y la prueba de (3).
- Mantener los pesos pero sustituir el ledger por el valor terminal puede destruir la disjunción de padres.
- En una fibra analítica, fallar (5) impide declarar isometría, aunque la probabilidad siga normalizada.
- Conservar norma no equivale a preservar un vector unidad; para eso se exige (6).
- Una reducción que no respete (4) disgrega las cinco operaciones o cambia su historia.
- Un lector no inyectivo conserva la norma de sus observables por medida imagen, pero no identifica todo el espacio de memoria.
- Para carga y defecto, fallar la naturalidad de la proyección en (9) impide transportar la separación ortogonal.
- Una familia analítica sin cota uniforme no queda cubierta por el teorema acotado del límite.

Estos resultados desarrollan una conservación estructural y operatoria precisa. No necesitan una campaña de decimales ni una afirmación sobre cardinalidad. Una identificación física particular conserva, además, su representación, sus observables y sus condiciones propias; no se infiere sólo del balance abstracto.
